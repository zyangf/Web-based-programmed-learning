/**
 * Created by YangZhuolin on 14/12/2015.
 */
$('input#quiz-submit').on('click', function()
{
   var name = $('input#answerOne').val();

}
);
