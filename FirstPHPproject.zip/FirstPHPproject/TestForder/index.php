<?php
/**
 * Created by PhpStorm.
 * User: YangZhuolin
 * Date: 20/01/2016
 * Time: 17:47
 */?>
<html>
<head>
    <title>AJAX Database</title>
</head>
<body>
    Name: <input type="text" id="name">
<input type="submit" id="name-submit">
<div id="name-data"></div>
    <script src="http://code.jquery.com/jquery-1.9.0.js"></script>
    <script src="HTMLstep1.js"></script>
</body>
</html>
