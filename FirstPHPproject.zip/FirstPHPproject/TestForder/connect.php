<?php
/**
 * Created by PhpStorm.
 * User: YangZhuolin
 * Date: 20/01/2016
 * Time: 18:09
 */
mysql_connect('localhost','root', '');