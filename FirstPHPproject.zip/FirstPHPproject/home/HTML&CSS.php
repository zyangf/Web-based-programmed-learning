
<?php include 'header.php' ?>

<?php

if ( $row == null ) {
    header('location: homepage.php');
}

?>

<div id="nav_main">
    <ul>
        <li><a href="HTMLSTEP1.php">Step 1</a></li>
        <li><a href="HTMLSTEP2.php">Step 2</a></li>
        <li><a href="HTMLSTEP3.php">Step 3</a></li>
        <li><a href="HTMLSTEP4.php">Step 4</a></li>
        <li><a href="HTMLSTEP5.php">Step 5</a></li>
        <li><a href="homepage.php">BACK</a></li>
        <li>
    </ul>
</div>
         <div id="content">

         <h1><?php echo"$row[$course_title]";?></h1>
         <p><?php echo"$row[$des]";?> </p>
             <br/>
          <p><?php echo "<img src='$row[$image]'"?></p>
       <a href="HTMLSTEP1.php"> <button type="start_learning" class="btn btn-primary btn-lg">Start Learning!</button></a>
   </div>
   
   <div id="footer"><p>CopyRights</p></div>
            
 </div>
        
        
</body>
</html>
