<?php
/**
 * Created by PhpStorm.
 * User: YangZhuolin
 * Date: 12/01/2016
 * Time: 14:12
 */
include "Stepheader.php"?>

<?php
$host = "localhost";
$user = "root";
$pass = "";
$db = "test";

$con=mysql_connect("localhost","root","");

if(!$con)
{
    die('Could not connect:' . mysql_error());
}
mysql_select_db("test",$con);

$html = "<a href='JavaScripStep2.php'>JavaScript Step2</a>";
$id = $_SESSION['id'];

if(isset($_POST['submit']))
{
    $sql = "UPDATE user SET active='" . mysql_real_escape_string($html) . "' WHERE id='$id'";
    $result = mysql_query($sql,$con);
    if($row=mysql_affected_rows($con))
    {
        echo"<script type='text/javascript'>alert('Successful!');</script>";
    }else{
        echo "fail";
    }
}
?>

<html xmlns="http://www.w3.org/1999/html">

<html>
<body>
<div id="nav_main">
    <ul>
        <li><a href="JavaScripStep1.php">Step 1</a></li>
        <li><a href="JavaScripStep2.php"><font color="red">Step 2</font></a></li>
        <li><a href="JavaScripStep3.php">Step 3</a></li>
        <li><a href="JavaScripStep4.php">Step 4</a></li>
        <li><a href="JavaScripStep5.php">Step 5</a></li>
        <li><a href="JavaScrip.php">&lt;&lt; BACK</a></li>
        <li><a href="DatePage.php">Test &gt;&gt;</a></li>
        <li>
    </ul>
</div>
<div id="content">
    <form method="post" action="JavaScripStep2.php"><h1>JavaScript Syntax / Step2
            <?php
            if(isset($_COOKIE['log']) && $_SESSION['type']==0){
                echo "<font style='margin-left:450px;' ><input name='submit' type='submit' class='btn btn-warning' id='Save' value='Save'></font>";
            } else{
                echo "<font style='margin-left: 450px;'><input type='submit' class='btn btn-warning' disabled='disabled' value='Save'></font>";
            }
            ?>
        </h1>
    </form>

    <hr/>
    <p class="topic">JavaScript Programs</p><br/>
    <p class="text">A <strong> computer program</strong> is a list of "instructions" to be "executed" by the computer. <br/>
    In a programming language, these program instructions are called <strong>statements</strong>. <br/>
    JavaScript is a <strong>programming language</strong>.
    JavaScript statements are separated by <strong>semicolons</strong>.</p>
    <p class="topic">JavaScript Statements</p><br/>
    <p class="text">JavaScript statements are composed of: <br/> Values, Operators, Expressions, Keywords, and Comments.</p>
    <p class="topic">JavaScript Variables</p><br/>
    <p class="text">In a programming language, <strong>variables</strong> are used to store data values.<br/>
    JavaScript uses the <strong>var</strong> keyword to <strong>declare</strong> variables.<br/>
    An <strong>equal sign</strong> is used to assign values to variables.<br/></p>
    <p class="topic">JavaScript Operators</p><br/>
    <p class="text">JavaScript uses an <strong>assignment operator</strong>(=)to <strong>assign</strong> values to variables;<br/>
    JavaScript uses <strong>arithmetic operators</strong>(+ - * /) to <strong>compute</strong> values.</p>
</div>
<div id="footer"><p>CopyRights</p></div>
</body>
</html>
