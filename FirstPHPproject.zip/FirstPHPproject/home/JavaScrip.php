<?php include 'header.php' ?>
<div id="nav_main">
    <ul>
        <li><a href="JavaScripStep1.php">Step 1</a></li>
        <li><a href="JavaScripStep2.php">Step 2</a></li>
        <li><a href="JavaScripStep3.php">Step 3</a></li>
        <li><a href="JavaScripStep4.php">Step 4</a></li>
        <li><a href="JavaScripStep5.php">Step 5</a></li>

        <li><a href="homepage.php">BACK</a></li>

        <li>
    </ul>
</div>

    <div id="content">
        <img src="../image/javascript.jpg" alt="javascript_code"/>
        <h1>JavaScrip</h1>
        <p>JavaScript is the programming language of <br>HTML and the Web.<br/> Programming makes computers do what you<br> want them to do. <br/>JavaScript is easy to learn.
            <br/>This tutorial will teach you JavaScript from <br>basic to advanced.</p>

        <a href="JavaScripStep1.php"> <button type="start_learning" class="btn btn-primary btn-lg">Start Learning!</button></a>
    </div>

    <div id="footer"><p>CopyRights</p></div>

</div>


</body>
</html>
