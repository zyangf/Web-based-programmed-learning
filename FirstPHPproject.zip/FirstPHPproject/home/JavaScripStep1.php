<?php
/**
 * Created by PhpStorm.
 * User: YangZhuolin
 * Date: 12/01/2016
 * Time: 12:57
 */
include 'Stepheader.php'?>

<?php
$host = "localhost";
$user = "root";
$pass = "";
$db = "test";

$con=mysql_connect("localhost","root","");

if(!$con)
{
    die('Could not connect:' . mysql_error());
}
mysql_select_db("test",$con);

$html = "<a href='JavaScripStep1.php'>JavaScrip Step1</a>";
$id = $_SESSION['id'];

if(isset($_POST['submit']))
{
    $sql = "UPDATE user SET active='" . mysql_real_escape_string($html) . "' WHERE id='$id'";
    $result = mysql_query($sql,$con);
    if($row=mysql_affected_rows($con))
    {
        echo"<script type='text/javascript'>alert('Successful!');</script>";
    }else{
        echo "fail";
    }
}
?>

<html xmlns="http://www.w3.org/1999/html">
<body>
<div id="nav_main">
    <ul>
        <li><a href="JavaScripStep1.php"><font color="red">Step 1</font></a></li>
        <li><a href="JavaScripStep2.php">Step 2</a></li>
        <li><a href="JavaScripStep3.php">Step 3</a></li>
        <li><a href="JavaScripStep4.php">Step 4</a></li>
        <li><a href="JavaScripStep5.php">Step 5</a></li>
        <li><a href="JavaScrip.php">&lt;&lt; BACK</a></li>
        <li><a href="StudentData.php">Test &gt;&gt;</a></li>
        <li>
    </ul>
</div>
<div id="content">
    <form method="post" action="JavaScripStep1.php"><h1>JavaScript Basic / Step 1
            <?php
            if(isset($_COOKIE['log']) && $_SESSION['type']==0){
                echo "<font style='margin-left:450px;' ><input name='submit' type='submit' class='btn btn-warning' id='Save' value='Save'></font>";
            } else{
                echo "<font style='margin-left: 450px;'><input type='submit' class='btn btn-warning' disabled='disabled' value='Save'></font>";
            }
            ?>
        </h1>
    </form>

    <hr>
    <p class="topic">JavaScript Introduction</p><br/>
    <p class="text">JavaScript is the most popular programming language in the world.<br/>
    This page contains some examples some examples of what JavaScript can do.</p>
    <p class="topic">JavaScript Can Change HTML Content</p><br />
    <p class="text">One of many HTML methods is <strong>getElementById().</strong><br/>
    This example uses the method to "find" an HTML element(with id="demo"), and changes the element content <strong>(innerHTML)</strong>to "Hello JavaScrip:</p>
    <img src="../image/JSstep1.PNG" alt="js_step1"style="height: 115px;"><br/><br/><br/>

    <p class="topic">JavaScript Can Change HTML and CSS Attributes by tag.</p>



</div>
<div id="footer"><p>CopyRights</p></div>
</body>
</html>

