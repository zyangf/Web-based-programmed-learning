<?php
session_start();
?>
<?php
$host = "localhost";
$user = "root";
$pass = "";
$db = "test";

$con=mysql_connect("localhost","root","");

if(!$con)
{
    die('Could not connect:' . mysql_error());
}
mysql_select_db("test",$con);
$sql = "SELECT * FROM user";
$result = mysql_query($sql, $con);

?>
<?php
if(!isset($_COOKIE['log'])){
    header("location:test_for_login.php");
}
if($_SESSION['type'] == 0)
{
    header("location:test_for_login.php");
}
?>

<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <title>Easy Learner</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../CSS/bootstrap.min.css">
    <link rel ="stylesheet" type="text/css" href="../CSS/userpage.css">
</head>
<body>
<div id="main_container">

    <div id="div_logo">
        <a href="homepage.php"/>
        <img src="../image/el.png" alt ="logo_el" width="136" height="108">
        </a>
    </div>

    <div id="div_login">
        <?php
        echo '<a href="adminPage.php"><img src="../image/UserLogo.png" alt="logo_user" width="68" height="54"></a>
         <br/>';
        echo $_SESSION['username'];
        echo "<br/>";
        echo "Teacher";

        echo '<br/>';

        echo '<a href="logout.php"><button type="button" class="btn bin-warning">Logout </button></a>';

        ?>
    </div>

    <div id="header">
        <h1> Learn to code interactively for free!</h1>
    </div>

    <div id="content">
        <h1> Study state</h1> <hr />

            <table class="table">
                <tr>
                    <th class="info" style="text-align:center;">Select one student to check</th>
                </tr>
                <?php
                while($row = mysql_fetch_assoc($result)){
                    if($row['type'] == 0){
                        echo "<tr>";
                        echo "<td style='text-align:center;'><a href='DatePage.php?id=".$row['id']."'><button type='button' class='btn btn-primary btn-lg' > ".$row['username']."</button></a></td>";
                        echo "<tr/>";
                    }
                }
                ?>

            </table>

    </div>
    <div id="footer"><p>CopyRights</p></div>
</div>

</body>
</html>