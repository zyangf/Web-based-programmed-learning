<?php include 'Testheader.php' ?>


<?php
$host = "localhost";
$descriptions = "root";
$pass = "";
$db = "course";

$con = mysql_connect("localhost", "root", "");
if(!$con)
{
    die('Could not connect:'.mysql_error());
}
mysql_select_db("course",$con);

$sql = "SELECT * FROM quiz, descriptions WHERE quiz.course_id = '" . $_SESSION['cid'] . "'AND descriptions.course_id = quiz.course_id" ;

$result = mysql_query($sql, $con);

$quiz = 'quiz';
$ans_a = 'ans_a';
$ans_b = 'ans_b';
$ans_c = 'ans_c';

$row = mysql_fetch_assoc($result);

?>

<html>
<body>
<div id="nav_main">
    <ul>
        <li><a href="HTMLSTEP1.php"><font color="red">Step 1</font></a></li>
        <li><a href="HTMLSTEP2.php">Step 2</a></li>
        <li><a href="HTMLSTEP3.php">Step 3</a></li>
        <li><a href="HTMLSTEP4.php">Step 4</a></li>
        <li><a href="HTMLSTEP5.php">Step 5</a></li>
        <li><a href="HTMLSTEP1.php">BACK</a></li>
        <li>
    </ul>
</div>
<div id="content">

    <h1> <?php echo "".$row['title'].""?> Test1</h1> <hr />

        <form action='feedback.php?id=1' method='post' id='quizForm' id='1'>
            <h1>Question</h1>
                    <?php
                        echo $row[$quiz];

                    ?>
                    <div>
                        <input type='radio' name='answerOne' id='answerOne' value='A' />
                        <label for='answerOne'>
                            <?php
                                echo $row[$ans_a];
                            ?> </label>
                    </div>
                    <div>
                        <input type='radio' name='answerOne' id='answerOne' value='B' />
                        <label for='answerOne'><?php
                                echo $row[$ans_b];
                            ?></label>
                    </div>
                    <div>
                        <input type='radio' name='answerOne' id='answerOne' value='C' />
                        <label for='answerOne'><?php

                                echo $row[$ans_c];

                            ?></label>
                    </div>
            <br>

            <input name='submit' type='submit' value='Submit Quiz' id="quiz-submit" class="btn btn-danger btn-lg active"/>


        </form>

    </div>

<div id="footer"><p>CopyRights</p></div>

</body>
</html>
