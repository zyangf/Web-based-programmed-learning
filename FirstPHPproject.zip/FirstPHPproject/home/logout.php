<?php
/**
 * Created by PhpStorm.
 * User: YangZhuolin
 * Date: 06/11/2015
 * Time: 19:08
 */
    unset($_SESSION);
    session_destroy();
    $seconds = -10 + time();
    setcookie(log,date("F jS - g:i a"),$seconds);
    header("location:../home/homepage.php");
?>