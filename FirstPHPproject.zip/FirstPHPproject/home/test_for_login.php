<?php include 'logheader.php' ?>

<?php
$host = "localhost";
$user = "root";
$pass = "";
$db = "course";

$con=mysqli_connect("localhost","root","","course");
if(!$con)
{
    die('Could not connect:' . mysql_error());
}

//mysqli_select_db("test",$con);

if(isset($_POST['username'])){
    $username = $_POST['username'];

    $password = $_POST['password'];
    if($username&&$password) {
        $sql = "SELECT * FROM user WHERE username=? AND password =? LIMIT 1";
        $stmt = $con->prepare($sql);
        $stmt->bind_param("ss", $username, $password);
        $stmt->execute();
        $stmt->bind_result($id, $username, $password, $email, $active, $type);
        $stmt->fetch();
        $stmt->close();
        //$result=mysqli_query($sql,$con);
        if(!empty($username)||!empty($password)) {

            $seconds = 120 * time();
            setcookie(log, date("F jS - g:i a"), $seconds);
            $_SESSION["username"] = $username;
            $_SESSION["type"] = $type;
            $_SESSION["id"] = $id;
            $_SESSION["active"] = $active;
            if ($type == 0) {

                header("location: userpage.php");
            }
            if ($type == 1) {

                header("location: adminPage.php");
            }
        }else {
            echo "Incorrect";
        }

        }else {
        echo "Please enter your username and password !";
    }
}

mysqli_close($con);
?>

<html>
<body>

<div id="nav_main">
    <li><a href="#">Course</li>
    <ul>
        <li><table>
           <?php
            while($row = mysql_fetch_assoc($result)) {
                echo "<tr>";
                echo "<td><a href='HTML&CSS.php?id=" . $row['course_id'] . "'>" . $row['title'] . "</a></td>";
                echo "</tr>";
            }
                ?>
        </table></li>

    </ul>


    <li><a href="#">News</a></li>

</div>
<div id="content">
<form class="form-horizontal" action="test_for_login.php" method="post">
    <div class="form-group">
    <label for="inputUsername"class="col-sm-2 control-label">User name:</label>
        <div class="col-sm-10">
            <input type="text" name="username" class="form-control" placeholder="Username">
        </div>
        <label for="inputPassword"class="col-sm-2 control-label">Password:</label>
        <div class="col-sm-10">
            <input type="password" name="password" class="form-control" placeholder="Password">
            <br/>
        </div>
        <div class="col-sm-10">
            <input type="submit" class="btn btn-primary" name="submit" value="Log In"/>
            <a href="RegistrationPage.php"><button type="button" class="btn btn-primary"> Create Account</button></a>
        </div>

    </div>

</form>
</div>
<div id="footer"><p>CopyRights</p></div>
</body>
</html>

