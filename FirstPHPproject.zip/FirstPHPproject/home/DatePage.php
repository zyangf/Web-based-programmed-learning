<?php include 'dataconncet.php' ?>
<?php
$host = "localhost";
$course = "root";
$pass = "";
$db = "course";

$con = mysql_connect("localhost", "root", "");
if(!$con){
    die('Could not connect:'.mysql_error());
}
mysql_select_db("course",$con);
$sql = "SELECT * FROM descriptions";
$result = mysql_query($sql, $con);
?>

<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <title>Easy Learner</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../CSS/bootstrap.min.css">
    <link rel ="stylesheet" type="text/css" href="../CSS/userpage.css">
</head>
<body>
<div id="main_container">

    <div id="div_logo">
        <a href="homepage.php"/>
        <img src="../image/el.png" alt ="logo_el" width="136" height="108">
        </a>
    </div>

    <div id="div_login">
        <?php
        echo '<a href="adminPage.php"><img src="../image/UserLogo.png" alt="logo_user" width="68" height="54"></a>
         <br/>';
        echo $_SESSION['username'];
        echo "<br/>";
        echo "Teacher";
        echo '<br/>';
        echo '<a href="logout.php"><button type="button" class="btn bin-warning">Logout </button></a>';

        ?>
    </div>

    <div id="header">
        <h1> Learn to code interactively for free!</h1>
    </div>

<div id="content">
    <h1> <?php echo "$row[$name]"?></h1> <hr />
    <table class="table">
        <div class="panel panel-primary">

            <?php
            $con = mysql_connect("localhost", "root", "");
            while($row = mysql_fetch_assoc($result)){

            $host = "localhost";
            $course = "root";
            $pass = "";
            $db = "course";

            if(!$con){
                die('Could not connect:'.mysql_error());
            }
            mysql_select_db("course", $con);
            $sql = "SELECT * FROM quiz WHERE course_id = '".$row["course_id"]."'";
            $result3 = mysql_query($sql, $con);
            $correct = 'correct';

            $ans = 'ans';
            $quiz_id = 'quiz_id';
            $user_id = 'user_id';
            $score = 0;
            while ( $row3  = mysql_fetch_assoc($result3) ) {
                //$_SESSION['qid'] = $quiz_id;
                $sql = "SELECT * FROM user_ans WHERE user_id = '" . $_GET['id'] . "' AND quiz_id = '" . $row3['id'] . "'";
                $result4 = mysql_query($sql, $con);

                while ($row4 = mysql_fetch_assoc($result4)) {
                    if ($row3[$correct] == $row4[$ans]) {
                        $score++;
                        break;
                    }
                }
            }
            $score = $score*100/5;

            echo "<tr>";
            echo "<td><div class='panel-group'><div class='panel-heading'>" . $row['title'] . "</div>
            <div class='panel-body'>
                <div class='progress'>
                   <div class='progress-bar progress-bar-success' role='progressbar' aria-valuenow='". $score."' aria-valuemin='0' aria-valuemax='100' style='width:". $score."%'>
                   ". $score."% Complete</div>
                </div>

            </div></td>";
            echo "</tr>";
        }
        ?>

        </div>
    </table>
    <?php
    echo "<p style='text-align:center;'><a href='commentPage.php?id=".$_SESSION['uid']."'><button type='button' class='btn btn-warning btn-lg'>Add Comment </button></a></p>";
    ?>
    </div>

<div id="footer"><p>CopyRights</p></div>
</body>
</html>
