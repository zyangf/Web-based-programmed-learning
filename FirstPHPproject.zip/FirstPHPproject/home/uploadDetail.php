<?php
session_start();
?>

<?php
/**
 * Created by PhpStorm.
 * User: YangZhuolin
 * Date: 06/02/2016
 * Time: 16:22
 */
include 'Dataconnect.php'?>

<?php
if(!isset($_COOKIE['log'])){
    header("location:test_for_login.php");
}
if($_SESSION['type'] == 0)
{
    header("location:test_for_login.php");
}
?>
<?php
$host = "localhost";
$course = "root";
$pass = "";
$db = "course";

$con = mysql_connect("localhost", "root", "");
if(!$con)
{
    die('Could not connect:'.mysql_error());
}
mysql_select_db("course",$con);


$sql = "SELECT * FROM descriptions WHERE course_id ='1' ";

$result = mysql_query($sql, $con);
$course_title='title';

$row = mysql_fetch_assoc($result);

?>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <title>Easy Learner</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../CSS/bootstrap.min.css">
    <link rel ="stylesheet" type="text/css" href="../CSS/userpage.css">
</head>
<body>
<div id="main_container">

    <div id="div_logo">
        <a href="homepage.php"/>
        <img src="../image/el.png" alt ="logo_el" width="136" height="108">
        </a>
    </div>

    <div id="div_login">
        <?php
        echo '<a href="adminPage.php"><img src="../image/UserLogo.png" alt="logo_user" width="68" height="54"></a>
         <br/>';
        echo $_SESSION['username'];
        echo "<br/>";
        echo "Teacher";

        echo '<br/>';

        echo '<a href="logout.php"><button type="button" class="btn bin-warning">Logout </button></a>';

        ?>
    </div>

    <div id="header">
        <h1> Learn to code interactively for free!</h1>
    </div>
    <div id="nav_main">

        <li><a href="#1">Course</a></li>
        <ul>
            <li><a href="HTML&CSS.php"><?php echo"$row[$course_title]"?></a> </li>
            <li><a href="JavaScrip.php"><?php echo "$row2[$course_title2]"?></a> </li>
        </ul>
        <li><a href="#">News</a></li>

    </div>
    <div id="content">
        <h1> <?php echo "$row2[$course_title2]"?></h1> <hr />
        <center><a href="updateQuiz5.php"><button type="button" class="btn btn-warning btn-lg"> Upload course description</button> </a></center>
        <br/>
        <center><a href="updateStep.php"><button type="button" class="btn btn-warning btn-lg"> Upload course step detail</button> </a></center>



    </div>
    <div id="footer"><p>CopyRights</p></div>
</div>

</body>
</html>
