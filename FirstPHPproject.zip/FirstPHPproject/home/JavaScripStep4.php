<?php
/**
 * Created by PhpStorm.
 * User: YangZhuolin
 * Date: 12/01/2016
 * Time: 15:20
 */
include "Stepheader.php" ?>

<html xmlns="http://www.w3.org/1999/html">
<body>
<div id="nav_main">
    <ul>
        <li><a href="JavaScripStep1.php">Step 1</a></li>
        <li><a href="JavaScripStep2.php">Step 2</a></li>
        <li><a href="JavaScripStep3.php">Step 3</a></li>
        <li><a href="JavaScripStep4.php">Step 4</a></li>
        <li><a href="JavaScripStep5.php">Step 5</a></li>
        <li><a href="JavaScrip.php">&lt;&lt; BACK</a></li>
        <li><a href="#">Test &gt;&gt;</a></li>
        <li>
    </ul>
</div>
<div id="content"></div>
<div id="footer"><p>CopyRights</p></div>
</body>
</html>
