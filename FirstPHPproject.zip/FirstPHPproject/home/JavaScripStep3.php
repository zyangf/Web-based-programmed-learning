<?php
/**
 * Created by PhpStorm.
 * User: YangZhuolin
 * Date: 12/01/2016
 * Time: 14:48
 */
include "Stepheader.php" ?>
<?php
$host = "localhost";
$user = "root";
$pass = "";
$db = "test";

$con=mysql_connect("localhost","root","");

if(!$con)
{
    die('Could not connect:' . mysql_error());
}
mysql_select_db("test",$con);

$html = "<a href='JavaScripStep3.php'>JavaScript Step3</a>";
$id = $_SESSION['id'];

if(isset($_POST['submit']))
{
    $sql = "UPDATE user SET active='" . mysql_real_escape_string($html) . "' WHERE id='$id'";
    $result = mysql_query($sql,$con);
    if($row=mysql_affected_rows($con))
    {
        echo"<script type='text/javascript'>alert('Successful!');</script>";
    }else{
        echo "fail";
    }
}
?>

<html xmlns="http://www.w3.org/1999/html">
<body>
<div id="nav_main">
    <ul>
        <li><a href="JavaScripStep1.php">Step 1</a></li>
        <li><a href="JavaScripStep2.php">Step 2</a></li>
        <li><a href="JavaScripStep3.php"><font color="red">Step 3</font></a></li>
        <li><a href="JavaScripStep4.php">Step 4</a></li>
        <li><a href="JavaScripStep5.php">Step 5</a></li>
        <li><a href="JavaScrip.php">&lt;&lt; BACK</a></li>
        <li><a href="dataconncet.php">Test &gt;&gt;</a></li>
        <li>
    </ul>
</div>
<div id="content">
    <form method="post" action="JavaScripStep3.php"><h1>JavaScript Statements / Step 3
            <?php
            if(isset($_COOKIE['log']) && $_SESSION['type']==0){
                echo "<font style='margin-left:450px;' ><input name='submit' type='submit' class='btn btn-warning' id='Save' value='Save'></font>";
            } else{
                echo "<font style='margin-left: 450px;'><input type='submit' class='btn btn-warning' disabled='disabled' value='Save'></font>";
            }
            ?>
        </h1>
    </form>
     <hr/>
    <p class="topic">JavaScript Statements</p><br/>
    <p class="text">This statement tells the browser to write "Hello Dolly." inside an HTML element with id =<strong>"demo".</strong> <br/>
    <strong>Example<br/></strong>
    document.getElementById("demo").innerHTML = "Hello Dolly."</p>
    <p class="topic">JavaScript Programs</p><br/>
    <p class="text">Most JavaScript programs contain many JavaScript statements. <br/>
    the statements are executed, one by one, in the same order as they are written.<br/>
    In this example, <strong>x</strong>, <strong>y</strong>, and <strong>z</strong> is given values, and finally <strong>z</strong> is displayed:<br/>
    <strong>Example</strong><br/>
    var x = 5;<br/>
    var y = 6;<br/>
    var z = x + y;<br>
    document.getElementById("demo").innerHTML = z; <br/>
    JavaScript variables are containers for storing data values.<br/>
    In the example, <strong>x</strong>, <strong>y</strong>, and <strong>z</strong> are variables: <br/>
    <strong>x</strong> stores the value 5<br/>
    <strong>y</strong> stores the value 6<br/>
    <strong>z</strong> stores the value 11.</p>

</div>
<div id="footer"><p>CopyRights</p></div>

</body>
</html>
