<?php include 'logheader.php' ?>
<?php
$host = "localhost";
$user = "root";
$pass = "";
$db = "course";

$con=mysql_connect("localhost","root","");

if(!$con)
{
    die('Could not connect:' . mysql_error());
}
mysql_select_db("course",$con);

if(isset($_POST['submit']))
{
    $username = $_POST['Username'];

    $password = $_POST['Password'];

    $email = $_POST['Email'];
    $type = $_POST['answerOne'];

    if($username&&$password&&$email&&$type){

        if(strlen($username) >25)
        {
            echo "Max limit for username are 25 characters";
        }else{
            if(strlen($password)>25 || strlen($password)<6){
                echo "Password must be between 6 and 25 characters";
            }else{
                if($type =="A")
                {
                    $type =1;
                }
                if($type == "B")
                {
                    $type = 0;
                }
                $sql = "INSERT INTO user (username, password, Email, type) VALUES ('$username', '$password', '$email', '$type')";

                $result = mysql_query($sql, $con);

                if($row = mysql_affected_rows($con))
                {
                    header("location: test_for_login.php");
                }else{
                    echo "fail";
                }
            }
        }

    }else
        echo "please fill in <b> all </b> fields !";
}

?>
<html  xmlns="http://www.w3.org/1999/html">
<body>
<div id="nav_main">
    <li><a href="#">Course</li>
    <ul>
        <li><a href="HTML&CSS.php"> HTML&CSS</a> </li>
        <li><a href="JavaScrip.php">JavaScrip</a> </li>
    </ul>
    </li>

    <li><a href="#">News</a></li>

</div>
    <div id="content">
    <h1>Register</h1>

    <form class="form-horizontal" method="post" action="RegistrationPage.php">
        <div class="form-group has-success has-feedback">

        <label class="control-label" for="Username">User Name:</label>
            <div class="col-sm-10">
                <input class="form-control" type="text" name="Username" id="Username" placeholder="Username" aria-describedby="inputSuccess2Status"/>
                <span class="glyphicon glyphicon-ok form-control-feedback" aria-hidden="true"></span>
                <span id="inputSuccess2Status" class="sr-only">(success)</span>
            </div>

        <label class="control-label" for="Password">Password:</label>
            <div class="col-sm-10">
                <input class="form-control" type="password" name="Password" id="Password" placeholder="Password" aria-describedby="inputSuccess2Status"/>
                <span class="glyphicon glyphicon-ok form-control-feedback" aria-hidden="true"></span>
                <span id="inputSuccess2Status" class="sr-only">(success)</span>
            </div>


            <label class="control-label" for="Email">Register Email:</label>
            <div class="col-sm-9">
                <div class="input-group">
                    <span class="input-group-addon">@</span>
                    <input type="text" class="form-control" name="Email" id="Email" placeholder="Email Address" aria-describedby="inputGroupSuccess2Status">
                </div>
                <span class="glyphicon glyphicon-ok form-control-feedback" aria-hidden="true"></span>
                <span id="inputGroupSuccess2Status" class="sr-only">(success)</span>
            </div>
<br/>
            <label class="control-label" for="option">
                Do you want to be a Teacher or Student?
            </label>
        <div>
            <input type='radio' name='answerOne' id='answerOne' value='A' />
            <label for='answerOne'>I want to be a teacher to teaching students. </label>
        </div>
        <div>
            <input type='radio' name="answerOne" id="answerOne" value="B"/>
            <label for="answerOne">I want to be a Student for learning.</label>
        </div>
        <br/>
        <input name="submit" type="submit" class="btn btn-success" id="Register" value="Register">
        </div>
    </form>
</div>
<div id="footer"><p>CopyRights</p></div>

</body>
</html>
