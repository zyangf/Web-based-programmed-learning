<?php include 'Stepheader.php' ?>
<?php
$host = "localhost";
$user = "root";
$pass = "";
$db = "test";

$con=mysql_connect("localhost","root","");

if(!$con)
{
    die('Could not connect:' . mysql_error());
}
mysql_select_db("test",$con);

$html = "<a href='HTMLSTEP3.php'>Step3</a>";
$id = $_SESSION['id'];

if(isset($_POST['submit']))
{
    $sql = "UPDATE user SET active='" . mysql_real_escape_string($html) . "' WHERE id='$id'";
    $result = mysql_query($sql,$con);
    if($row=mysql_affected_rows($con))
    {
        echo"<script type='text/javascript'>alert('Successful!');</script>";
    }else{
        echo "fail";
    }
}
?>
<?php
$host = "localhost";
$descriptions = "root";
$pass = "";
$db = "course";

$con = mysql_connect("localhost", "root", "");
if(!$con)
{
    die('Could not connect:'.mysql_error());
}
mysql_select_db("course",$con);

$sql = "SELECT * FROM step, descriptions WHERE step.course_id = '" . $_SESSION['cid'] . "' AND step_id='3'";

$result = mysql_query($sql, $con);
$step_title='step_title';
$step_contents='step_contents';
$step_image = 'step_images';
$row = mysql_fetch_assoc($result);

?>
<div id="nav_main">
    <ul>
        <li><a href="HTMLSTEP1.php">Step 1</a></li>
        <li><a href="HTMLSTEP2.php">Step 2</a></li>
        <li><a href="HTMLSTEP3.php"><font color="red">Step 3</font></a></li>
        <li><a href="HTMLSTEP4.php">Step 4</a></li>
        <li><a href="HTMLSTEP5.php">Step 5</a></li>
        <li><a href="HTMLSTEP2.php">&lt;&lt; BACK</a></li>
        <li><a href="testHTML3.php">Test &gt;&gt;</a></li>
        <li>
    </ul>
</div>
<div id="content">
    <form method="post" action="HTMLSTEP3.php"><h1><?php echo"$row[$step_title]";?>
            <?php
            if(isset($_COOKIE['log']) && $_SESSION['type']==0){
                echo "<font style='margin-left:450px;' ><input name='submit' type='submit' class='btn btn-warning' id='Save' value='Save'></font>";
            } else{
                echo "<font style='margin-left: 450px;'><input type='submit' class='btn btn-warning' disabled='disabled' value='Save'></font>";
            }
            ?>
        </h1>
    </form><hr />
    <p class="topic"><?php echo"$row[$step_title]";?></p><br />
    <p class="text"> <?php echo "$row[$step_contents]";?></p><br/>
    <p><?php echo "<img src='$row[$step_image]'"?></p>


</div>
<div id="footer"><p>CopyRights</p></div>

</div>
</body>
</html>
