<?php
session_start();
?>
<?php
$host = "localhost";
$course = "root";
$pass = "";
$db = "course";

$con = mysql_connect("localhost", "root", "");
if(!$con)
{
    die('Could not connect:'.mysql_error());
}
mysql_select_db("course",$con);


$sql = "SELECT * FROM descriptions";

$result = mysql_query($sql, $con);

$course_title = 'title';

?>

<?php
if(!isset($_COOKIE['log'])){
    header("location:test_for_login.php");
}
if($_SESSION['type'] == 0)
{
    header("location:test_for_login.php");
}
?>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <title>Easy Learner</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../CSS/bootstrap.min.css">
    <link rel ="stylesheet" type="text/css" href="../CSS/userpage.css">
</head>
<body>
<div id="main_container">

    <div id="div_logo">
        <a href="homepage.php"/>
        <img src="../image/el.png" alt ="logo_el" width="136" height="108">
        </a>
    </div>

    <div id="div_login">
        <img src="../image/UserLogo.png" alt="logo_user" width="68" height="54">
        <br/>
        <?php
        echo $_SESSION['username'];
        ?>
        <br/>

        <a href="logout.php"><button type="button" class="btn bin-warning">Logout </button></a>
    </div>

    <div id="header">
        <h1> Learn to code interactively for free!</h1>
    </div>

    <div id="content">
        <h1>Account Detail</h1>
        <p><center><font color="red" size="8">Teacher Account</font></center></p>
        <center><img src="../image/MyAccount.jpg" alt="image_user" width="160"height="160" class="img-circle"> <br/>
        <?php
        echo $_SESSION['username'];
        ?>
            <br/>
      <a href="Upload.php"><button type="button" class="btn btn-warning btn-lg">Go to Upload Page</button></a><br/><br/>
        <a href="StudentData.php"><button type="button" class="btn btn-warning btn-lg">See Student Study state</button></a> </center>
    </div>

    <div id="footer"><p>CopyRights</p></div>

</div>

</body>
</html>

