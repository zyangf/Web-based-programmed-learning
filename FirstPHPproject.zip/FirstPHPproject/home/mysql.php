<?php
/**
 * Created by PhpStorm.
 * User: YangZhuolin
 * Date: 31/10/2015
 * Time: 14:25
 */

$servername = "localhost";
$username = "root";
$password = "";
$conn = new mysqli($servername, $username, $password);

if($conn->connect_error){
    die("Connection failed: ".$conn->connect_error);
}
echo "Connected successfully";

if(@login($conn, $username, $password))
{
    echo "Connection established.";
}
else
{
    echo "Couln't establish a connection.";
}
?>


