<?php
session_start();
?>
<?php
if(!isset($_COOKIE['log'])){
    header("location:test_for_login.php");
}
if($_SESSION['type'] == 0)
{
    header("location:test_for_login.php");
}
?>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <title>Easy Learner</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../CSS/bootstrap.min.css">
    <link rel ="stylesheet" type="text/css" href="../CSS/TestStyle.css">
</head>
<body>
<div id="main_container">

    <div id="div_logo">
        <a href="homepage.php"/>
        <img src="../image/el.png" alt ="logo_el" width="136" height="108">
        </a>
    </div>

    <div id="div_login">
        <?php
        echo '<a href="adminPage.php"><img src="../image/UserLogo.png" alt="logo_user" width="68" height="54"></a>
         <br/>';
        echo $_SESSION['username'];
        echo "<br/>";
        echo "Teacher";

        echo '<br/>';

        echo '<a href="logout.php"><button type="button" class="btn bin-warning">Logout </button></a>';

        ?>
    </div>

    <div id="header">
        <h1> Learn to code interactively for free!</h1>
    </div>
    <?php
    $host = "localhost";
    $user = "root";
    $pass = "";
    $db = "course";

    $con=mysql_connect("localhost","root","");

    if(!$con)
    {
        die('Could not connect:' . mysql_error());
    }
    mysql_select_db("course",$con);

    if(isset($_POST['submit']))
    {
        $course_id = $_POST['course_id'];
        $course_title = $_POST['Title'];
        $description = $_POST['Description'];
        $image = $_POST['Image'];

        $_SESSION['course_id'] = $course_id;
        if($course_title && $description && $image) {

            $sql = "INSERT INTO descriptions(course_id, title, descriptions, image) VALUES ('$course_id','$course_title','$description','$image')";

            $result = mysql_query($sql, $con);

            if($row = mysql_affected_rows($con))
            {
                header("location: uploadStep1.php");
            }else{
                echo "fail";
            }
    }else{
        echo "please fill in <b> all </b> fields !";
    }
}

?>

<div id="content">

    <form method="post" action="UploadPage.php">

        <label for="Id">What course id number do you want to upload ?</label>
        <input class="form-control input-lg" type="number" placeholder="Course Id"  value="course id" name="course_id"/>


        <label for="Title">What course title do you want to upload?</label>
        <input class="form-control input-lg" type="text" placeholder="Course Title" name="Title" id="Title"/>

        <label for="Description">What kind of course description do you want to upload/</label>
        <textarea class="form-control input-lg" rows="5" placeholder="Course Description" name="Description" id="Description"></textarea>

        <br/>
        <label for="Image">Upload image file follow with address (../image/filename):</label>
        <input class="form-control input-lg" type="text" placeholder="../image/filename" name="Image" id="Image"><br/>
        <center><input name="submit" type="submit" class="btn btn-success btn-lg" id="Upload" value="Upload"></center>
    </form>

</div>
<div id="footer"><p>CopyRights</p></div>
</body>
</html>
