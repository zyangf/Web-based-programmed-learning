<?php
session_start();
?>
<?php
if(!isset($_COOKIE['log'])){
    header("location:test_for_login.php");
}
if($_SESSION['type'] == 0)
{
    header("location:test_for_login.php");
}
?>
<?php
$host = "localhost";
$course = "root";
$pass = "";
$db = "course";

$con = mysql_connect("localhost", "root", "");
if(!$con)
{
    die('Could not connect:'.mysql_error());
}
mysql_select_db("course",$con);

$sql = "SELECT * FROM step, descriptions WHERE course_id = '" . $_SESSION['cid2'] . "'";

$result = mysql_query($sql, $con);
?>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <title>Easy Learner</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../CSS/bootstrap.min.css">
    <link rel ="stylesheet" type="text/css" href="../CSS/TestStyle.css">
</head>
<body>
<div id="main_container">

    <div id="div_logo">
        <a href="homepage.php"/>
        <img src="../image/el.png" alt ="logo_el" width="136" height="108">
        </a>
    </div>

    <div id="div_login">
        <?php
        echo '<a href="adminPage.php"><img src="../image/UserLogo.png" alt="logo_user" width="68" height="54"></a>
         <br/>';
        echo $_SESSION['username'];
        echo "<br/>";
        echo "Teacher";

        echo '<br/>';

        echo '<a href="logout.php"><button type="button" class="btn bin-warning">Logout </button></a>';

        ?>
    </div>

    <div id="header">
        <h1> Learn to code interactively for free!</h1>
    </div>

    <?php
    $host = "localhost";
    $user = "root";
    $pass = "";
    $db = "course";

    $con=mysqli_connect("localhost","root","","course");
    if(!$con)
    {
        die('Could not connect:' . mysql_error());
    }
    //mysql_select_db("test",$con);

    if(isset($_POST['submit']))
    {
        $step_title = $_POST['Step'];
        $step_contents = $_POST['Contents'];
        $step_images = $_POST['Images'];
        if($step_title && $step_contents && $step_images) {

            $sql = "UPDATE step SET step_title=?, step_contents=?, step_images=? WHERE course_id = '" . $_SESSION['cid2'] . "'AND step_id='3'";

            $stmt = $con->prepare($sql);
            $stmt->bind_param('sss', $step_title, $step_contents, $step_images);
            $stmt->execute();

            $stmt->fetch();
            $stmt->close();
            header("location: updateStep.php");
        }
    }

    mysqli_close($con);
    ?>

    <div id="content">

        <form method="POST" action="updateStep3.php">
            <h1>Update Step three</h1><hr/>

            <label for="Step">What is this course step ?</label>
            <input class="form-control input-lg" type="text" placeholder="Course Step" name="Step" id="Step"/>

            <label for="Contents">What is the course contents do you want to upload?</label>
            <textarea class="form-control input-lg" rows="5" placeholder="Course Contents" name="Contents" id="Contents"></textarea>

            <br/>
            <label for="Images">Upload image file follow with address (../image/filename):</label>
            <input class="form-control input-lg" type="text" placeholder="../image/filename" name="Images" id="Images">
            <br/>
            <center><input name="submit" type="submit" class="btn btn-success btn-lg" id="Update" value="Update"></center>
        </form>


    </div>
    <div id="footer"><p>CopyRights</p></div>
</body>
</html>