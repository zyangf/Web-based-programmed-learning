<?php
session_start();
?>

<?php
if(!isset($_COOKIE['log'])){
    header("location:test_for_login.php");
}
if($_SESSION['type'] == 0)
{
    header("location:test_for_login.php");
}
?>
<?php
$host = "localhost";
$course = "root";
$pass = "";
$db = "course";

$con = mysql_connect("localhost", "root", "");
if(!$con)
{
    die('Could not connect:'.mysql_error());
}
mysql_select_db("course",$con);

$sql = "SELECT * FROM descriptions WHERE course_id = '" . $_SESSION['cid2'] . "'";

$result = mysql_query($sql, $con);
$title = 'title';
$row = mysql_fetch_assoc($result);

?>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <title>Easy Learner</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../CSS/bootstrap.min.css">
    <link rel ="stylesheet" type="text/css" href="../CSS/TestStyle.css">
</head>
<body>
<div id="main_container">

    <div id="div_logo">
        <a href="homepage.php"/>
        <img src="../image/el.png" alt ="logo_el" width="136" height="108">
        </a>
    </div>

    <div id="div_login">
        <?php
        echo '<a href="adminPage.php"><img src="../image/UserLogo.png" alt="logo_user" width="68" height="54"></a>
         <br/>';
        echo $_SESSION['username'];
        echo "<br/>";
        echo "Teacher";

        echo '<br/>';

        echo '<a href="logout.php"><button type="button" class="btn bin-warning">Logout </button></a>';

        ?>
    </div>

    <div id="header">
        <h1> Learn to code interactively for free!</h1>
    </div>

    <?php
    $host = "localhost";
    $user = "root";
    $pass = "";
    $db = "course";

    $con=mysqli_connect("localhost","root","","course");
    if(!$con)
    {
        die('Could not connect:' . mysql_error());
    }
    //mysql_select_db("test",$con);

    if(isset($_POST['submit']))
    {
        $course_title = $_POST['Title'];
        $description = $_POST['Description'];

        $image = $_POST['Image'];
        if($course_title && $description && $image) {

            $sql = "UPDATE descriptions SET title=?, descriptions=?, image=? WHERE course_id = '" . $_SESSION['cid2'] . "'";

            $stmt = $con->prepare($sql);
            $stmt->bind_param('sss', $course_title, $description, $image);
            $stmt->execute();

            $stmt->fetch();
            $stmt->close();
            header("location: UpdatePage2.php");
        }else{
            echo "<script type='text/javascript'>alert('please fill in  all fields !');</script>";
        }
    }

    mysqli_close($con);
    ?>

    <div id="content">

        <form method="POST" action="updateDesp.php">

            <label for="Title">What course title do you want to update?</label>
            <input class="form-control input-lg" type="text" placeholder="Course Title" name="Title" id="Title"/>

            <label for="Description">What kind of course description do you want to update?</label>
            <textarea class="form-control input-lg" rows="5" placeholder="Course Description" name="Description" id="Description"></textarea>

            <br/>
            <label for="Image">Upload image file follow with address (../image/filename):</label>
            <input class="form-control input-lg" type="text" placeholder="../image/filename" name="Image" id="Image"><br/>
            <center><input name="submit" type="submit" class="btn btn-success btn-lg" id="Update" value="Update"></center>
        </form>


    </div>
    <div id="footer"><p>CopyRights</p></div>
</body>
</html>