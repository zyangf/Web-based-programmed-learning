<?php
session_start();
?>
<?php
$host = "localhost";
$course = "root";
$pass = "";
$db = "course";

$con = mysql_connect("localhost", "root", "");
if(!$con)
{
    die('Could not connect:'.mysql_error());
}
mysql_select_db("course",$con);


$sql = "SELECT * FROM descriptions";

$result = mysql_query($sql, $con);

?>

<?php
$host = "localhost";
$course = "root";
$pass = "";
$db = "course";

$con = mysql_connect("localhost", "root", "");
if(!$con)
{
    die('Could not connect:'.mysql_error());
}
mysql_select_db("course",$con);


$sql = "SELECT * FROM comment WHERE user_id = '".$_SESSION['id']."'";

$result2 = mysql_query($sql, $con);
$count = 0;
while($row2 =mysql_fetch_assoc($result2)){
    if($row2['id'] >0)
    {
        $count++;
    }
}
?>
<?php
    if(!isset($_COOKIE['log'])) {
        header("location:test_for_login.php");
    }
if($_SESSION['type'] == 1)
{
    header("location:test_for_login.php");
}
?>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <title>Easy Learner</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../CSS/bootstrap.min.css">
    <link rel ="stylesheet" type="text/css" href="../CSS/userpage.css">
</head>
<body>
<div id="main_container">

    <div id="div_logo">
        <a href="homepage.php"/>
        <img src="../image/el.png" alt ="logo_el" width="136" height="108">
        </a>
    </div>

    <div id="div_login">
        <img src="../image/UserLogo.png" alt="logo_user" width="68" height="54">
        <br/>
        <?php
        echo $_SESSION['username'];

        ?>
        <br/>

        <a href="logout.php"><button type="button" class="btn bin-warning">Logout </button></a>
    </div>

    <div id="header">
        <h1> Learn to code interactively for free!</h1>
    </div>

    <div id="nav_main">
        <li><a href="#">Course</li>
        <ul>
            <li><table>
                    <?php
                    while($row = mysql_fetch_assoc($result)) {
                        echo "<tr>";
                        echo "<td><a href='HTML&CSS.php?id=" . $row['course_id'] . "'>" . $row['title'] . "</a></td>";
                        echo "</tr>";
                    }
                    ?>
                </table></li>

        </ul>

        <li><a href="studentComment.php">Comment<span class="badge"><?php echo "$count"?></span> </a></li>

    </div>
    <div id="content">
        <h1>Account Detail</h1>
        <p class="text">Student Account</p>
       <center><img src="../image/MyAccount.jpg" alt="image_user" width="160"height="160" class="img-circle"></center>  <br/>
       <center><?php
           echo $_SESSION['username'];
           ?></center>
        <br/>
        <center> <p class="text bg-primary">Continue Study<br/>
           <?php echo "<button type='button' class='btn btn-warning btn-lg'>".$_SESSION['active']."</button>";?></p> </center>
        <br/>
        <?php
        echo "<p style='text-align:center;'><a href='StudentSelfData.php?id=".$_SESSION['id']."'><button type='button' class='btn btn-info btn-lg'>See test state</button></a></p>";
        ?>

    </div>

    <div id="footer"><p>CopyRights</p></div>

</div>

</body>
</html>





