<?php
/**
 * Created by PhpStorm.
 * User: YangZhuolin
 * Date: 23/12/2015
 * Time: 16:42
 */
include 'Testheader.php' ?>
<?php
$host = "localhost";
$user = "root";
$pass = "";
$db = "course";

$con=mysql_connect("localhost","root","");

if(!$con)
{
    die('Could not connect:' . mysql_error());
}
mysql_select_db("course",$con);

if(isset($_POST['submit']))
{
    $ans = $_POST['answerOne'];
    $id = $_SESSION['id'];

    if($ans == 'A')
    {
        $ans = 1;
    }
    if($ans == 'B'){
        $ans = 2;
    }
    if($ans == 'C'){
        $ans = 3;
    }

    $sql = "SELECT id FROM quiz WHERE quiz_id='1' AND course_id = '" . $_SESSION['cid'] . "'";
    $res = mysql_query($sql, $con);
    $id2 = 'id';
    $row2 = mysql_fetch_assoc($res);


    $sql = "INSERT INTO user_ans(quiz_id, ans, user_id) VALUES ('$row2[$id2]','$ans', '$id')";

    $result = mysql_query($sql, $con);
    $row = mysql_affected_rows($con);

}
$sql = "SELECT * FROM quiz, descriptions WHERE quiz.course_id = '" . $_SESSION['cid'] . "'AND quiz_id='3'" ;

$result = mysql_query($sql, $con);

$feedbackA = 'fed_a';
$feedbackB = 'fed_b';
$feedbackC = 'fed_c';

$row = mysql_fetch_assoc($result);

?>
<html>
<body>
<div id="nav_main">
    <ul>
        <li><a href="HTMLSTEP1.php">Step 1</a></li>
        <li><a href="HTMLSTEP2.php">Step 2</a></li>
        <li><a href="HTMLSTEP3.php"><font color="red">Step 3</font></a></li>
        <li><a href="HTMLSTEP4.php">Step 4</a></li>
        <li><a href="HTMLSTEP5.php">Step 5</a></li>
        <li><a href="HTMLSTEP3.php">BACK</a></li>
        <li>
    </ul>
</div>
<div id="content">
    <?php

    $fid = $_GET['id'];

    ?>
    <center><font face="Andalus" size="5">Feedback</font></center>
    <br />
    <br />

    <?php
    $answer1= $_POST['answer'];

    if ($answer1 == "A"){
        echo"<center><font face='Berlin Sans FB' size='8' color='red'> $row[$feedbackA]</font></center>";

    }else if($answer1 == "B"){
        echo "<center><font face='Berlin Sans FB' size='8' color='red'>$row[$feedbackB]</font></center>";

    }else if($answer1 == "C"){
        echo "<center><font face='Berlin Sans FB' size='8' color='red'>$row[$feedbackC]</font></center>";

    }else
    {
        echo "<center><font face='Berlin Sans FB' size='8' color= red>You haven't choose any answer, please back to try again !</font></center>";
    }


        echo '<center><a href="HTMLSTEP4.php"><button style="width: 300px;
                padding: 20px;
                font-weight: bold;
                font-size: 150%;
                background: #3366CC;
                color: #FFFFFF;
                cursor: pointer;
                border: 1px solid #999999;
                border-radius: 10px;
                -webkit-box-shadow: 6px 6px 5px #999999;
                -moz-box-shadow: 6px 6px 5px #999999;
    ">Next Step</button></a></center>';

        echo '<center><a href="HTMLSTEP3.php"><button style="width: 300px;
                padding: 20px;
                font-weight: bold;
                font-size: 150%;
                background: #3366CC;
                color: #FFFFFF;
                cursor: pointer;
                border: 1px solid #999999;
                border-radius: 10px;
                -webkit-box-shadow: 6px 6px 5px #999999;
                -moz-box-shadow: 6px 6px 5px #999999;
    ">Back to study</button></a></center>';


    ?>
</div>
<div id="footer"><p>CopyRights</p></div>
</body>
</html>
