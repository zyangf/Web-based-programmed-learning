<?php
session_start();
?>
<?php
if(!isset($_COOKIE['log'])){
    header("location:test_for_login.php");
}
if($_SESSION['type'] == 0)
{
    header("location:test_for_login.php");
}
?>
<?php
$host = "localhost";
$course = "root";
$pass = "";
$db = "course";

$con = mysql_connect("localhost", "root", "");
if(!$con)
{
    die('Could not connect:'.mysql_error());
}
mysql_select_db("course",$con);

$sql = "SELECT * FROM quiz, descriptions WHERE course_id = '" . $_SESSION['cid2'] . "'";

$result = mysql_query($sql, $con);
?>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <title>Easy Learner</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../CSS/bootstrap.min.css">
    <link rel ="stylesheet" type="text/css" href="../CSS/TestStyle.css">
</head>
<body>
<div id="main_container">

    <div id="div_logo">
        <a href="homepage.php"/>
        <img src="../image/el.png" alt ="logo_el" width="136" height="108">
        </a>
    </div>

    <div id="div_login">
        <?php
        echo '<a href="adminPage.php"><img src="../image/UserLogo.png" alt="logo_user" width="68" height="54"></a>
         <br/>';
        echo $_SESSION['username'];
        echo "<br/>";
        echo "Teacher";

        echo '<br/>';

        echo '<a href="logout.php"><button type="button" class="btn bin-warning">Logout </button></a>';

        ?>
    </div>

    <div id="header">
        <h1> Learn to code interactively for free!</h1>
    </div>

    <?php
    $host = "localhost";
    $user = "root";
    $pass = "";
    $db = "course";

    $con=mysqli_connect("localhost","root","","course");
    if(!$con)
    {
        die('Could not connect:' . mysql_error());
    }
    //mysql_select_db("test",$con);

    if(isset($_POST['submit']))
    {
        $quiz = $_POST['Quiz'];
        $ans_a = $_POST['Ansa'];
        $ans_b = $_POST['Ansb'];
        $ans_c = $_POST['Ansc'];
        $fed_a = $_POST['Feda'];
        $fed_b = $_POST['Fedb'];
        $fed_c = $_POST['Fedc'];
        if($quiz&&$ans_a&&$ans_b&&$ans_c&&$fed_a&&$fed_b&&$fed_c) {

            $sql = "UPDATE quiz SET quiz=?, ans_a=?, ans_b=?, ans_c=?, fed_a=?, fed_b=?, fed_c=? WHERE course_id = '" . $_SESSION['cid2'] . "'AND quiz_id='5'";
            $stmt = $con->prepare($sql);
            $stmt->bind_param('sssssss', $quiz, $ans_a, $ans_b, $ans_c, $fed_a, $fed_b, $fed_c);
            $stmt->execute();
            $stmt->fetch();
            $stmt->close();
            header("location: updateQuiz.php");
        }else{
            echo "please fill in <b> all </b> fields !";
        }

    }

    mysqli_close($con);
    ?>

    <div id="content">

        <form method="POST" action="updateQuiz5.php">
            <h1>Update Quiz Five</h1><hr/>

            <label for="Quiz">What question do you want to upload?</label>
            <input class="form-control input-lg" type="text" placeholder="Quiz" name="Quiz" id="Quiz"/>

            <label for="Ansa">Select one:</label>
            <input class="form-control input-lg" type="text" placeholder="Ans_a" name="Ansa" id="Ansa"/>


            <label for="Ans_b">Select two:</label>
            <input class="form-control input-lg" type="text" placeholder="Ans_b" name="Ansb" id="Ansb"/>

            <label for="Ans_c">Select three:</label>
            <input class="form-control input-lg" type="text" placeholder="Ans_c" name="Ansc" id="Ansc"/>

            <label for="Fed_a">Feedback one:</label>
            <input class="form-control input-lg" type="text" placeholder="Feedback" name="Feda" id="Feda"/>

            <label for="Fed_b">Feedback two:</label>
            <input class="form-control input-lg" type="text" placeholder="Feedback2" name="Fedb" id="Fedb"/>

            <label for="Fed_c">Feedback three:</label>
            <input class="form-control input-lg" type="text" placeholder="Feedback3" name="Fedc" id="Fedc"/>

            <br/>
            <center><input name="submit" type="submit" class="btn btn-success btn-lg" id="Update" value="Update"></center>
        </form>

    </div>
    <div id="footer"><p>CopyRights</p></div>
</body>
</html>