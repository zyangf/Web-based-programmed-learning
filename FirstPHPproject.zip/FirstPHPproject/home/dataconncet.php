<?php
session_start();
?>
<?php
if(!isset($_COOKIE['log'])){
    header("location:test_for_login.php");
}
if($_SESSION['type'] == 0)
{
    header("location:test_for_login.php");
}
?>
<?php
$host = "localhost";
$user = "root";
$pass = "";
$db = "test";

$con = mysql_connect("localhost", "root", "");

if(!$con)
{
    die('Could not connect:'.mysql_error());
}
mysql_select_db("test", $con);
$row = null;
if(isset($_GET['id'])&&preg_match("/^[0-9]+$/", $_GET['id']) == 1)
{
    $sql = "SELECT * FROM user WHERE id = '".$_GET['id']."'";

    $result = mysql_query($sql, $con);
    $name = 'username';
    $row = mysql_fetch_assoc($result);
    $_SESSION['uid'] = $_GET['id'];
}

?>
