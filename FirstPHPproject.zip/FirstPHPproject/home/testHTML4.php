<?php
/**
 * Created by PhpStorm.
 * User: YangZhuolin
 * Date: 23/12/2015
 * Time: 17:20
 */
include "Testheader.php" ?>

<?php
$host = "localhost";
$descriptions = "root";
$pass = "";
$db = "course";

$con = mysql_connect("localhost", "root", "");
if(!$con)
{
    die('Could not connect:'.mysql_error());
}
mysql_select_db("course",$con);

$sql = "SELECT * FROM quiz, descriptions WHERE quiz.course_id = '" . $_SESSION['cid'] . "'AND descriptions.course_id = quiz.course_id AND quiz_id='4'" ;

$result = mysql_query($sql, $con);
$quiz = 'quiz';
$ans_a = 'ans_a';
$ans_b = 'ans_b';
$ans_c = 'ans_c';

$row = mysql_fetch_assoc($result);

?>

<html xmlns="http://www.w3.org/1999/html">
<body>
<div id="nav_main">
    <ul>
        <li><a href="HTMLSTEP1.php">Step 1</a></li>
        <li><a href="HTMLSTEP2.php">Step 2</a></li>
        <li><a href="HTMLSTEP3.php">Step 3</a></li>
        <li><a href="HTMLSTEP4.php"><font color="red">Step 4</font></a></li>
        <li><a href="HTMLSTEP5.php">Step 5</a></li>
        <li><a href="HTMLSTEP4.php">BACK</a></li>
        <li>
    </ul>
</div>
<div id="content">

    <h1> <?php echo "".$row['title']." test4"?></h1> <hr />

    <form action='feedback4.php?id=1' method='post' id='quizForm' id='1'>

        <h1>Question</h1>
        <?php echo $row[$quiz];?>
        <div>
            <input type='radio' name='answer' id='answer' value='A' />
            <label for='answerA'><?php echo $row[$ans_a];?></label>
        </div>
        <div>
            <input type='radio' name='answer' id='answer' value='B' />
            <label for='answerB'><?php echo $row[$ans_b];?></label>
        </div>
        <div>
            <input type='radio' name='answer' id='answer' value='C' />
            <label for='answerC'><?php echo $row[$ans_c];?></label>
        </div>
        <br>

        <input name='submit' type='submit' value='Submit Quiz' id="quiz-submit" class="btn btn-danger btn-lg active"/>

    </form>

</div>

<div id="footer"><p>CopyRights</p></div>

</body>
</html>
