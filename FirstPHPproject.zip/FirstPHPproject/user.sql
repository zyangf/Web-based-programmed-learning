-- phpMyAdmin SQL Dump
-- version 4.5.0.2
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Feb 29, 2016 at 12:52 PM
-- Server version: 10.0.17-MariaDB
-- PHP Version: 5.6.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `course`
--

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `username` varchar(1024) NOT NULL,
  `password` varchar(32) NOT NULL,
  `email` varchar(1024) NOT NULL,
  `active` text NOT NULL,
  `type` int(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `username`, `password`, `email`, `active`, `type`) VALUES
(5, 'zhuolin', '19930828', 'zyangf@essex.ac.uk', '<a href=''HTMLSTEP1.php?cid=3''>Step1</a>', 0),
(7, 'scott', 'scott123', 'scott@essex.ac.uk', '0', 1),
(8, 'wang', 'wang456', 'wang@gamil.com', '0', 1),
(9, 'JIN', 'jin123', 'jin@essex.ac.uk', '0', 0),
(10, 'JZ WU', '999999', 'ads@qq.com', '0', 1),
(11, 'ChuanKai', '111111', '111111', '0', 0),
(12, 'xiang', 'xiang456', 'xiang@qq.com', '0', 0),
(13, 'yang', 'yang000', 'yang@qq.com', '<a href=''HTMLSTEP1.php''>Step1</a>', 0),
(14, 'Easy Learner', 'learnercom', 'learner@easy.com', '0', 1),
(15, 'sun', 'sun123', 'sun@qq.com', '0', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
